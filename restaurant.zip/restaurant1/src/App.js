import React from 'react';
import './App.css';
import Menu from './Components/menu/menu'
import Checkbox from './Components/test/test'

function App() {
  return (
    <div className="App">
      <h1>Restaurant Menu</h1>
      <Menu />
    </div>
  );
}

export default App;
