import React, { Component } from 'react';
import { directive } from '@babel/types';
import './menu.css'
import SaladChecked from '../SaladChecked/SaladChecked'
const hoediv = {
    margin: '0px',
    border: '5px solid pink'
  };


class Menu extends React.Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        this.handleChecked = this.handleChecked.bind(this); // set this, because you need get methods from CheckBox 
      }
      handleChecked () {
        this.setState({isChecked: !this.state.isChecked});
      }
      render(){
        var txt;
        if (this.state.isChecked ) {
          return (
            <SaladChecked />
          );
        } else {
          txt = 'unchecked'
        }
      return (
        <div className="hoediv">
            <input type="checkbox" onChange={ this.handleChecked } value="salad"/>Salad<br />
            <input type="checkbox" value="entree"/>Entree<br />
            <input type="checkbox" onChange={ this.handleChecked } value="soup"/>Soup<br />
        </div>
        
   );
}
}

export default Menu;