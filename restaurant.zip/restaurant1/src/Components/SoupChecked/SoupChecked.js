import React, { Component } from 'react';
import { directive } from '@babel/types';
import MilestoneChecked  from'./milestoneChecked'

const hoediv = {
    margin: '0px',
  };
const saladselected = {
    margin: '0 0 0 4em',
  };

class SoupChecked extends React.Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        this.handleChecked = this.handleChecked.bind(this); // set this, because you need get methods from CheckBox 
      }
      handleChecked () {
        this.setState({isChecked: !this.state.isChecked});
      }
      render(){
        var txt;
        if (this.state.isChecked) {
          return (
           <MilestoneChecked />
          );
        }
         else {
            return(
                <div style ={hoediv}>
                <input type="checkbox" value="salad"/>Salad<br />
                
                <input type="checkbox" value="entree"/>Entree<br />
                <input type="checkbox" checked value="soup"/>Soup<br />
                <div style ={saladselected}>
                    <input type="checkbox" onChange={ this.handleChecked } value="entree"/>Minestone<br />
                    <input type="checkbox" value="entree"/>Hot and Sour<br />
                    <input type="checkbox" value="entree"/>Miso<br />
                </div>
                
            </div>
            );
        }
    }
}
export default SoupChecked

