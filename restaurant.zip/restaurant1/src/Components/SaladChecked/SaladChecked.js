import React, { Component } from 'react';
import { directive } from '@babel/types';
import GreekChecked from'./GreekChecked'

const hoediv = {
    margin: '0px',
  };
const saladselected = {
    margin: '0 0 0 4em',
  };

class SaladChecked extends React.Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        this.handleChecked = this.handleChecked.bind(this); // set this, because you need get methods from CheckBox 
      }
      handleChecked () {
        this.setState({isChecked: !this.state.isChecked});
      }
      render(){
        var txt;
        if (this.state.isChecked) {
          return (
           <GreekChecked />
          );
        }
         else {
            return(
                <div style ={hoediv}>
                <input type="checkbox" checked value="salad"/>Salad<br />
                    
                <div style ={saladselected}>
                    <input type="checkbox" onChange={ this.handleChecked } value='greek'/>Greek<br />
                    <input type="checkbox" value='asian'/>Asian<br />
                    <input type="checkbox" value='santafee'/>Santa Fee<br />
                    
                </div>
                <input type="checkbox" value="entree"/>Entree<br />
                <input type="checkbox" value="soup"/>Soup<br />
                
            </div>
            );
        }
    }
}
export default SaladChecked

