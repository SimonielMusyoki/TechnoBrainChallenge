import React, { Component } from 'react';
import { directive } from '@babel/types';

const hoediv = {
    margin: '0px',
  };
const saladselected = {
    margin: '0 0 0 4em',
  };
const greekselected = {
    margin: '0 0 0 4em',
  };

const dressingselected = {
    margin: '0 0 0 4em',
  };

class DressingChecked extends React.Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        this.handleChecked = this.handleChecked.bind(this); // set this, because you need get methods from CheckBox 
      }
      handleChecked () {
        this.setState({isChecked: !this.state.isChecked});
      }
      render(){
        var txt;
        if (this.state.isChecked) {
          return (
            <div>
                 <p>Thanks for your selection </p>
            </div>
          );
        } else {
            return (
                <div style ={hoediv}>
                <input type="checkbox" id="salad" checked value="salad"/>Salad<br />
                    
                <div style ={saladselected}>
                    <input type="checkbox" value='asian'/>Santa Fee<br />
                    <input type="checkbox" checked value='greek'/>Greek<br />
                    <input type="checkbox" value='asian'/>Asian<br />
                    <div style ={greekselected}>
                        <h5>You might also want:</h5>
                        <div style ={hoediv}>
                            <input type="checkbox" checked onChange={ this.handleChecked } value='dressing'/>Dressing<br />
                            <div tyle ={dressingselected }>
                                <input type="checkbox" value='dressing'/>Italian<br />
                                <input type="checkbox" checked value='dressing'/>Blue Cheese<br />
                                <input type="checkbox" value='dressing'/>Ranch<br />
                            </div>
                            <input type="checkbox" value='bread'/>Bread<br />
                        </div>
                    </div>
                </div>
                <input type="checkbox" value="entree"/>Entree<br />
                <input type="checkbox" value="soup"/>Soup<br />
            
            </div>
            );
        }
      
    }
}
export default DressingChecked
