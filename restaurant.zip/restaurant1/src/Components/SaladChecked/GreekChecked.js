import React, { Component } from 'react';
import { directive } from '@babel/types';
import DressingChecked from'./DressingChecked'

const hoediv = {
    margin: '0px',
  };
const saladselected = {
    margin: '0 0 0 4em',
  };
const greekselected = {
    margin: '0 0 0 4em',
  };
class GreekChecked extends React.Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        this.handleChecked = this.handleChecked.bind(this); // set this, because you need get methods from CheckBox 
      }
      handleChecked () {
        this.setState({isChecked: !this.state.isChecked});
      }
      render(){
        var txt;
        if (this.state.isChecked) {
          return (
            <DressingChecked />
          );
        } else {
            return(
            <div style ={hoediv}>
                <input type="checkbox" id="salad" checked value="salad"/>Salad<br />
                    
                <div style ={saladselected}>
                    <input type="checkbox" value='asian'/>Santa Fee<br />
                    <input type="checkbox" checked value='greek'/>Greek<br />
                    <input type="checkbox" value='asian'/>Asian<br />
                    <div style ={greekselected}>
                        <h5>You might also want:</h5>
                        <div className="otherLikes">
                            <input type="checkbox" onChange={ this.handleChecked } value='dressing'/>Dressing<br />
                            <input type="checkbox" value='bread'/>Bread<br />
                        </div>
                    </div>
                </div>
                <input type="checkbox" value="entree"/>Entree<br />
                <input type="checkbox" value="soup"/>Soup<br />
            
            </div>
      );
    }
}
}
export default GreekChecked
