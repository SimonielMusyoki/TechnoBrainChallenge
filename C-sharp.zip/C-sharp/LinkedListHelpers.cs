using System;
using System.Collections.Generic; 

namespace C_sharp
{
    static class LinkedListHelpers
    {
        public static void ReceiveRootNode(){
            public static LinkedList<String> my_list = new LinkedList<String>(); 
            string liststring = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
        }
    }
}