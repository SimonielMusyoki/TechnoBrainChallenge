﻿using System;

namespace C_sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(LinkedListHelpers.my_list);
        }
    }
}
